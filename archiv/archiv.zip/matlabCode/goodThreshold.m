function[threshold] = goodThreshold(input)

threshold = mean2(input)
end